import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


class LinearRegressionWithSlope:
    def __init__(self, learning_rate=0.01, no_of_itr=1000):
        self.learning_rate = learning_rate
        self.no_of_itr = no_of_itr

    def fit(self, X, Y):
        self.m = np.zeros(X.shape[1])  # Slope (one for each feature)
        self.c = 0  # Intercept
        self.X = X
        self.Y = Y
        self.n = len(self.Y)

        # Gradient descent
        for _ in range(self.no_of_itr):
            self.update_weights()

    def update_weights(self):
        # Predicted values
        Y_prediction = np.dot(self.X, self.m) + self.c

        # Compute gradients for m and c
        dm = -(2 / self.n) * np.dot(self.X.T, (self.Y - Y_prediction))
        dc = -(2 / self.n) * np.sum(self.Y - Y_prediction)

        # Update m, c
        self.m -= self.learning_rate * dm
        self.c -= self.learning_rate * dc

    def predict(self, X):
        return np.dot(X, self.m) + self.c

    def print_weights(self):
        print("Slopes (m):", self.m)
        print("Intercept (c):", self.c)


if __name__ == "__main__":
    # Load dataset
    df = pd.read_csv("abalone.csv")  # Ensure the dataset is correctly formatted

    # Drop categorical column 'Sex'
    df = df.drop(columns=["Sex"])

    # Features and target variable
    X = df.drop(columns=["Rings"]).values  # Excluding the target column
    y = df[["Rings"]].values  # Target column

    # Train-test split ratio
    split_ratio = 0.8
    split_index = int(split_ratio * len(df))

    X_train = X[:split_index]
    y_train = y[:split_index]
    X_test = X[split_index:]
    y_test = y[split_index:]

    # Train the model
    learning_rate = 0.01
    iterations = 1000
    model = LinearRegressionWithSlope(learning_rate, iterations)
    model.fit(X_train, y_train)

    model.print_weights()

    # Predict on test data
    y_pred = model.predict(X_test)

    # Evaluation metrics
    def mean_squared_error(y_true, y_pred):
        return np.mean((y_true - y_pred) ** 2)

    def r2_score(y_true, y_pred):
        ss_total = np.sum((y_true - np.mean(y_true)) ** 2)
        ss_residual = np.sum((y_true - y_pred) ** 2)
        return 1 - (ss_residual / ss_total)

    mse = mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)

    print("Mean Squared Error:", mse)
    print("R-Squared:", r2)
