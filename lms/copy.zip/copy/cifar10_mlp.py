import numpy as np
import pickle

# Load CIFAR-10 dataset


def load_cifar10_batch(filename):
    with open(filename, "rb") as f:
        batch = pickle.load(f, encoding="bytes")
    images = batch[b"data"] / 255.0  # Normalize
    labels = np.array(batch[b"labels"])
    return images, labels


# Load all batches


def load_cifar10():
    X_train, Y_train = [], []
    for i in range(1, 6):
        images, labels = load_cifar10_batch(f"cifar-10-batches-py/data_batch_{i}")
        X_train.append(images)
        Y_train.append(labels)
    X_train = np.vstack(X_train)
    Y_train = np.hstack(Y_train)
    X_test, Y_test = load_cifar10_batch("cifar-10-batches-py/test_batch")
    return X_train, Y_train, X_test, Y_test


# One-hot encoding


def one_hot_encode(labels, num_classes=10):
    return np.eye(num_classes)[labels]


# Initialize MLP parameters


def initialize_parameters(input_size, hidden_size, output_size):
    np.random.seed(42)
    W1 = np.random.randn(input_size, hidden_size) * 0.01
    b1 = np.zeros((1, hidden_size))
    W2 = np.random.randn(hidden_size, output_size) * 0.01
    b2 = np.zeros((1, output_size))
    return W1, b1, W2, b2


# Activation functions


def relu(Z):
    return np.maximum(0, Z)


def softmax(Z):
    exp_Z = np.exp(Z - np.max(Z, axis=1, keepdims=True))
    return exp_Z / np.sum(exp_Z, axis=1, keepdims=True)


# Forward propagation


def forward_propagation(X, W1, b1, W2, b2):
    Z1 = np.dot(X, W1) + b1
    A1 = relu(Z1)
    Z2 = np.dot(A1, W2) + b2
    A2 = softmax(Z2)
    return Z1, A1, Z2, A2


# Compute loss


def compute_loss(A2, Y):
    m = Y.shape[0]
    log_probs = -np.log(A2[range(m), Y.argmax(axis=1)])
    return np.sum(log_probs) / m


# Backward propagation


def backward_propagation(X, Y, Z1, A1, A2, W1, W2):
    m = X.shape[0]
    dZ2 = A2 - Y
    dW2 = np.dot(A1.T, dZ2) / m
    db2 = np.sum(dZ2, axis=0, keepdims=True) / m
    dA1 = np.dot(dZ2, W2.T)
    dZ1 = dA1 * (Z1 > 0)
    dW1 = np.dot(X.T, dZ1) / m
    db1 = np.sum(dZ1, axis=0, keepdims=True) / m
    return dW1, db1, dW2, db2


# Update parameters


def update_parameters(W1, b1, W2, b2, dW1, db1, dW2, db2, learning_rate):
    W1 -= learning_rate * dW1
    b1 -= learning_rate * db1
    W2 -= learning_rate * dW2
    b2 -= learning_rate * db2
    return W1, b1, W2, b2


# Train the model


def train(
    X_train, Y_train, X_test, Y_test, hidden_size=128, epochs=20, learning_rate=0.01
):
    input_size, output_size = X_train.shape[1], Y_train.shape[1]
    W1, b1, W2, b2 = initialize_parameters(input_size, hidden_size, output_size)

    for epoch in range(epochs):
        Z1, A1, Z2, A2 = forward_propagation(X_train, W1, b1, W2, b2)
        loss = compute_loss(A2, Y_train)
        dW1, db1, dW2, db2 = backward_propagation(X_train, Y_train, Z1, A1, A2, W1, W2)
        W1, b1, W2, b2 = update_parameters(
            W1, b1, W2, b2, dW1, db1, dW2, db2, learning_rate
        )

        if epoch % 5 == 0:
            print(f"Epoch {epoch}: Loss = {loss:.4f}")

    test_accuracy = evaluate(X_test, Y_test, W1, b1, W2, b2)
    print(f"Test Accuracy: {test_accuracy:.2f}%")
    return W1, b1, W2, b2


# Evaluate model


def evaluate(X, Y, W1, b1, W2, b2):
    _, _, _, A2 = forward_propagation(X, W1, b1, W2, b2)
    predictions = np.argmax(A2, axis=1)
    labels = np.argmax(Y, axis=1)
    accuracy = np.mean(predictions == labels) * 100
    return accuracy


# Load and preprocess CIFAR-10
dataset_path = "cifar-10-batches-py/"
X_train, Y_train, X_test, Y_test = load_cifar10()
Y_train, Y_test = one_hot_encode(Y_train), one_hot_encode(Y_test)

# Train and test the model
W1, b1, W2, b2 = train(X_train, Y_train, X_test, Y_test)

test_accuracy = evaluate(X_test, Y_test, W1, b1, W2, b2)
print(f"Final Test Accuracy: {test_accuracy:.2f}%")
